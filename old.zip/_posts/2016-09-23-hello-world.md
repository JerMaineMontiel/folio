---
title: Hello World.
date: '2016-09-23 00:00:00'
layout: post
summary: Hang on to your butts!
tags: hello welcome
---
Hey there. Glad you stopped by.

I don't really know what to tell you, other than your discretion is advised. I don't know whether this blog will help you or hurt you, but it's here. I hope it does help you, though. If you came from a Google search, or from my tweets, or you're some kinda creep (don't be creepy), I hope you get what you need here.

I started this blog to catalogue the work I'm doing on various projects, as a way to come back for reference and to keep those that care up to date with where I'm at. I'm gonna try and be as detailed and layman as I can. It's gonna be real informal here; I'll try my hardest not to bore you. Coding can get boring sometimes, especially when you're constantly researching tools and plugins and methodologies for whatever it is you're building. So having something that's an entertaining read *and* clear and to the point is always welcome.

And I'm welcoming to feedback! If I'm not doing these things, if something isn't clear or have any questions just give me a shout by email at <span>hey@jermaine.fyi</span> or on <a href="http://twitter.com/{{ site.twitter_username }}" target="_blank">Twitter</a>. (Twitter might be the quickest; I'm always on there)

Alright, that's it for this intro. In my first post I'll be breaking down what it is I'm building, and why I made the choices I did. Hope you come back!